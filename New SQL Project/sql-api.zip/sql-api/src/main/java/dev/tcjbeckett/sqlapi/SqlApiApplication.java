package dev.tcjbeckett.sqlapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SqlApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SqlApiApplication.class, args);
	}

}
