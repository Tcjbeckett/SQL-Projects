package dev.tcjbeckett.sqlapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SqlApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
